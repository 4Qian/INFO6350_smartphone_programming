//
//  Wonder.swift
//  Midterm
//
//  Created by 李谦 on 3/18/23.
//

import Foundation

class Wonder{
    var title: String;
    var imageName: String;
    var description: String;
    init(title: String, imageName: String, description: String) {
        self.title = title
        self.imageName = imageName
        self.description = description
    }
}
