//
//  Constants.swift
//  MidtermAPICall
//
//  Created by 李谦 on 3/18/23.
//

import Foundation

let apiKey = "9b44448f04333f5b73c0e476e175a7e6"
let baseURL = "https://financialmodelingprep.com/api/v3/profile/"
